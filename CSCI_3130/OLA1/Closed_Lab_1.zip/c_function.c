// Greg Wagner
// CSCI-3130 Dr. Phillips
// OLA1
// c_function.c

#include <stdio.h>

void c_function(const char *haiku)
{
	
	puts(haiku);

	return;
}